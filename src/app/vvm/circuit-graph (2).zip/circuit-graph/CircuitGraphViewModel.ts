import {
  Component, input, OnInit, OnDestroy, computed, signal,
  ChangeDetectionStrategy, ElementRef, ViewChild, AfterViewInit, NgZone
} from '@angular/core';
import { CommonModule } from '@angular/common';

// ─── Types ─────────────────────────────────────────────────────────────────

export type CircuitComponent = {
  name: string;
  type: string;
  nodes: string[];
  values: Record<string, string> | null;
};

export type Point   = { x: number; y: number };
export type CompPos = Record<string, Point>;

export type NodePath = {
  id: string;
  d: string;
  junctions: Point[];
  labelX: number;
  labelY: number;
};

export type WireData = {
  nodePaths:  NodePath[];
  gndBusX1:   number; gndBusX2: number; gndBusY: number;
  gndCentreX: number; gndDrops: Point[];
  vddBusX1:   number; vddBusX2: number; vddBusY: number;
  vddCentreX: number; vddDrops: Point[]; vddLabelX: number;
};

// ─── Colours (dark on white) ───────────────────────────────────────────────

export const TYPE_COLORS: Record<string, string> = {
  Resistor:      'var(--cg-type-resistor)',
  VoltageSource: 'var(--cg-type-voltage)',
  CurrentSource: 'var(--cg-type-current)',
  Mosfet:        'var(--cg-type-mosfet)',
  Capacitor:     'var(--cg-type-capacitor)',
  Inductor:      'var(--cg-type-inductor)',
  default:       'var(--cg-type-default)',
};

const WIRE_SIGNAL = 'var(--cg-wire-signal)';
const WIRE_VDD    = 'var(--cg-wire-vdd)';
const WIRE_GND    = 'var(--cg-wire-gnd)';
const SNAP        = 10;

function normalizeType(type: string): string {
  const t = (type ?? '').toLowerCase();
  if (t === 'mosfet' || t === 'transistor' || t === 'bjt' || t === 'npn' || t === 'pnp') return 'Mosfet';
  if (t === 'resistor') return 'Resistor';
  if (t === 'capacitor') return 'Capacitor';
  if (t === 'inductor') return 'Inductor';
  if (t === 'voltagesource' || t === 'vsource' || t === 'vsrc') return 'VoltageSource';
  if (t === 'currentsource' || t === 'isource' || t === 'isrc') return 'CurrentSource';
  return type;
}

function kindOf(comp: CircuitComponent): string {
  const normalized = normalizeType(comp.type);
  if (normalized !== comp.type) return normalized;

  const rawType = (comp.type ?? '').toLowerCase();
  const name    = (comp.name ?? '').toLowerCase();
  const nodeCnt = comp.nodes?.length ?? 0;

  // Heuristics for generated netlists that use non-standard type labels.
  // - SPICE MOS devices commonly start with M, BJTs with Q
  // - many generated transistor entries have 3 or 4 nodes
  if (name.startsWith('m') || name.startsWith('q')) return 'Mosfet';
  if (rawType.includes('fet') || rawType.includes('transistor') || rawType.includes('bjt')) return 'Mosfet';
  if (nodeCnt >= 3 && nodeCnt <= 4 && normalized === comp.type) return 'Mosfet';

  return normalized;
}

// ─── Layout ────────────────────────────────────────────────────────────────

export function computeLayout(comps: CircuitComponent[]): CompPos {
  if (comps.length === 0) return {};

  // Build adjacency: two components are adjacent if they share a node
  const adjacency = new Map<string, Set<string>>();
  comps.forEach(c => adjacency.set(c.name, new Set()));

  const nodeMap = new Map<string, string[]>();
  comps.forEach(comp => {
    comp.nodes.forEach(nid => {
      if (!nodeMap.has(nid)) nodeMap.set(nid, []);
      nodeMap.get(nid)!.push(comp.name);
    });
  });
  nodeMap.forEach(names => {
    for (let i = 0; i < names.length; i++)
      for (let j = i + 1; j < names.length; j++) {
        adjacency.get(names[i])?.add(names[j]);
        adjacency.get(names[j])?.add(names[i]);
      }
  });

  // BFS-based layout: place components in a grid guided by connections.
  // Each "level" (column) contains components that are the same number of hops
  // from the leftmost source/voltage-source anchor.
  const COL_GAP = 220;
  const ROW_GAP = 180;

  // Prefer voltage/current sources as roots so they appear on the left edge.
  const roots = comps.filter(c =>
    kindOf(c) === 'VoltageSource' || kindOf(c) === 'CurrentSource'
  );
  const ordered: string[] = [];
  const visited = new Set<string>();
  const level   = new Map<string, number>();

  const enqueue = (name: string, lvl: number) => {
    if (visited.has(name)) return;
    visited.add(name);
    level.set(name, lvl);
    ordered.push(name);
    // BFS neighbours sorted for determinism
    const nbrs = [...(adjacency.get(name) ?? [])].sort();
    nbrs.forEach(n => enqueue(n, lvl + 1));
  };

  // Seed with roots first, then any unvisited
  roots.forEach(r => enqueue(r.name, 0));
  comps.forEach(c => enqueue(c.name, level.get(c.name) ?? 0));

  // Assign column = BFS level, row = order within column
  const colCounts = new Map<number, number>();
  const pos: CompPos = {};

  ordered.forEach(name => {
    const col = level.get(name) ?? 0;
    const row = colCounts.get(col) ?? 0;
    colCounts.set(col, row + 1);
    pos[name] = {
      x: 120 + col * COL_GAP,
      y: 120 + row * ROW_GAP,
    };
  });

  return pos;
}

// ─── Terminal positions ────────────────────────────────────────────────────

export function terminalPoint(comp: CircuitComponent, idx: number, pos: CompPos): Point {
  const p = pos[comp.name] ?? { x: 0, y: 0 };
  switch (kindOf(comp)) {
    case 'Resistor': case 'Inductor':
      // Prefer horizontal (left/right) terminals so components can connect side-by-side.
      // idx 0 = left terminal, idx 1 = right terminal.
      return idx === 0 ? { x: p.x - 32, y: p.y } : { x: p.x + 32, y: p.y };
    case 'Capacitor':
      return idx === 0 ? { x: p.x - 32, y: p.y } : { x: p.x + 32, y: p.y };
    case 'VoltageSource': case 'CurrentSource':
      // Sources connect top (positive, idx 0) and bottom (negative/GND, idx 1)
      return idx === 0 ? { x: p.x, y: p.y - 38 } : { x: p.x, y: p.y + 38 };
    case 'Mosfet':
      if (idx === 0) return { x: p.x + 22, y: p.y - 40 };  // Drain (top-right)
      if (idx === 1) return { x: p.x - 40, y: p.y };       // Gate (left)
      return { x: p.x + 22, y: p.y + 40 };                 // Source (bottom-right)
    default:
      return idx === 0 ? { x: p.x - 22, y: p.y } : { x: p.x + 22, y: p.y };
  }
}

// ─── Wire routing ──────────────────────────────────────────────────────────

const rnd = (v: number) => Math.round(v * 10) / 10;

function lRoute(a: Point, b: Point): string {
  if (Math.abs(a.x - b.x) < 2) return `M${rnd(a.x)},${rnd(a.y)} L${rnd(b.x)},${rnd(b.y)}`;
  if (Math.abs(a.y - b.y) < 2) return `M${rnd(a.x)},${rnd(a.y)} L${rnd(b.x)},${rnd(b.y)}`;
  return `M${rnd(a.x)},${rnd(a.y)} L${rnd(a.x)},${rnd(b.y)} L${rnd(b.x)},${rnd(b.y)}`;
}

function buildNodeWirePath(pts: Point[]): string {
  if (pts.length < 2) return '';
  if (pts.length === 2) return lRoute(pts[0], pts[1]);

  // Use a vertical bus at the median X position so wires connect from left AND right.
  const xs    = pts.map(p => p.x).sort((a, b) => a - b);
  const busX  = xs[Math.floor(xs.length / 2)];
  const minY  = Math.min(...pts.map(p => p.y));
  const maxY  = Math.max(...pts.map(p => p.y));

  // Vertical spine
  let d = `M${rnd(busX)},${rnd(minY)} L${rnd(busX)},${rnd(maxY)}`;

  // Horizontal branches from each terminal to the spine
  pts.forEach(p => {
    if (Math.abs(p.x - busX) > 2) {
      d += ` M${rnd(p.x)},${rnd(p.y)} L${rnd(busX)},${rnd(p.y)}`;
      // Short vertical stub if the point doesn't sit exactly on the spine
      if (Math.abs(p.y - minY) > 2 && Math.abs(p.y - maxY) > 2) {
        // already on the spine via the horizontal branch — nothing extra needed
      }
    }
  });

  return d;
}

// ─── Component ─────────────────────────────────────────────────────────────

@Component({
  selector: 'circuit-graph',
  standalone: true,
  imports: [CommonModule],
  templateUrl: 'CircuitGraphViewModel.html',
  styleUrl: 'CircuitGraphViewModel.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CircuitGraphViewModel implements OnInit, AfterViewInit, OnDestroy {

  readonly json = input.required<string>();

  @ViewChild('svgRoot') svgRootRef!: ElementRef<SVGGElement>;
  @ViewChild('svgEl')   svgElRef!:   ElementRef<SVGSVGElement>;

  protected comps   = signal<CircuitComponent[]>([]);
  protected pos     = signal<CompPos>({});
  protected selComp = signal<string | null>(null);
  protected xfm     = signal({ x: 0, y: 0, s: 1 });

  // Computed signal — re-runs whenever pos() or comps() changes (e.g. on drag)
  protected wires = computed<WireData>(() => {
    const comps = this.comps();
    const pos   = this.pos();

    const nodeMap = new Map<string, { comp: CircuitComponent; idx: number }[]>();
    comps.forEach(comp => {
      comp.nodes.forEach((nid, idx) => {
        if (!nodeMap.has(nid)) nodeMap.set(nid, []);
        const list = nodeMap.get(nid)!;
        if (!list.find(e => e.comp.name === comp.name && e.idx === idx))
          list.push({ comp, idx });
      });
    });

    const ptsFor = (nid: string): Point[] =>
      (nodeMap.get(nid) ?? []).map(e => terminalPoint(e.comp, e.idx, pos));

    const gndPts   = ptsFor('0');
    const gndBusY  = gndPts.length ? Math.max(...gndPts.map(p => p.y)) + 70 : 600;
    const gndXs    = gndPts.map(p => p.x);
    const gndBusX1 = (gndXs.length ? Math.min(...gndXs) : 0) - 50;
    const gndBusX2 = (gndXs.length ? Math.max(...gndXs) : 0) + 50;

    const vdd = comps.find(c =>
      (kindOf(c) === 'VoltageSource' || kindOf(c) === 'CurrentSource') &&
      !(c.values?.['dc_value'] ?? '').includes(' 0')
    );
    const vddNodeId = vdd?.nodes[0];
    const vddPts    = vddNodeId ? ptsFor(vddNodeId) : [];
    const vddBusY   = vddPts.length ? Math.min(...vddPts.map(p => p.y)) - 40 : -100;
    const vddXs     = vddPts.map(p => p.x);
    const vddBusX1  = (vddXs.length ? Math.min(...vddXs) : 0) - 50;
    const vddBusX2  = (vddXs.length ? Math.max(...vddXs) : 0) + 50;

    const nodePaths: NodePath[] = [];
    nodeMap.forEach((entries, nid) => {
      if (nid === '0' || nid === vddNodeId) return;
      const pts = entries.map(e => terminalPoint(e.comp, e.idx, pos));
      if (pts.length < 2) return;
      const first = pts[0];
      nodePaths.push({
        id:        nid,
        d:         buildNodeWirePath(pts),
        junctions: pts.length >= 3 ? pts : [],
        labelX:    first.x + 6,
        labelY:    first.y - 6,
      });
    });

    return {
      nodePaths,
      gndBusX1, gndBusX2, gndBusY,
      gndCentreX: (gndBusX1 + gndBusX2) / 2,
      gndDrops:   gndPts,
      vddBusX1, vddBusX2, vddBusY,
      vddCentreX: (vddBusX1 + vddBusX2) / 2,
      vddDrops:   vddPts,
      vddLabelX:  vddBusX1 - 6,
    };
  });

  protected readonly WIRE_SIGNAL = WIRE_SIGNAL;
  protected readonly WIRE_VDD    = WIRE_VDD;
  protected readonly WIRE_GND    = WIRE_GND;

  private panActive = false;
  private panStart  = { x: 0, y: 0 };
  private panOrigin = { x: 0, y: 0 };
  private dragState: { name: string; startMx: number; startMy: number; startCx: number; startCy: number } | null = null;
  private resizeObserver: ResizeObserver | null = null;

  protected panningState = signal(false);
  protected isPanning    = this.panningState.asReadonly();

  constructor(private zone: NgZone) {}

  // ── Init ────────────────────────────────────────────────────────────────

  ngOnInit() {
    const parsed: { components: CircuitComponent[] } = JSON.parse(this.json());
    this.comps.set(parsed.components);
    this.pos.set(computeLayout(parsed.components));
  }

  ngAfterViewInit() {
    const container = this.svgElRef?.nativeElement;
    if (!container) return;

    // ResizeObserver fires as soon as the element has non-zero dimensions.
    // We fit once on the first real measurement, then disconnect.
    this.resizeObserver = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect;
      if (width > 0 && height > 0) {
        // Run inside Angular zone so signal updates trigger CD
        this.zone.run(() => this.fitAll());
      }
    });
    this.resizeObserver.observe(container);

    // Extra delayed fit for cases where SVG bounds are not ready on first resize event.
    setTimeout(() => {
      this.zone.run(() => this.fitAll());
    }, 120);
  }

  ngOnDestroy() {
    this.resizeObserver?.disconnect();
  }

  // ── Template helpers ────────────────────────────────────────────────────

  protected color(comp: CircuitComponent): string {
    return TYPE_COLORS[this.normalizedType(comp)] ?? TYPE_COLORS['default'];
  }

  protected normalizedType(comp: CircuitComponent): string {
    return kindOf(comp);
  }

  protected compPos(name: string): Point {
    return this.pos()[name] ?? { x: 0, y: 0 };
  }

  protected svgTransform(): string {
    const { x, y, s } = this.xfm();
    return `translate(${x},${y}) scale(${s})`;
  }

  protected zoomLabel(): string {
    return Math.round(this.xfm().s * 100) + '%';
  }

  private isDarkMode(): boolean {
    return document.documentElement.classList.contains('dark');
  }

  protected componentBodyFill(): string {
    return this.isDarkMode() ? 'rgba(245, 178, 107, 0.16)' : '#ffffff';
  }

  protected selectionFill(): string {
    return this.isDarkMode() ? 'rgba(245, 178, 107, 0.14)' : '#ffffff';
  }

  protected selectedData(): CircuitComponent | null {
    const name = this.selComp();
    return name ? (this.comps().find(c => c.name === name) ?? null) : null;
  }

  protected valueEntries(comp: CircuitComponent): { k: string; v: string }[] {
    return comp.values ? Object.entries(comp.values).map(([k, v]) => ({ k, v })) : [];
  }

  protected readonly resistorPoints = '0,-16 -9,-12 9,-8 -9,-4 9,0 -9,4 9,8 -9,12 0,16';

  // ── Interaction ─────────────────────────────────────────────────────────

  protected onCompMouseDown(e: MouseEvent, name: string) {
    e.stopPropagation();
    e.preventDefault();
    const p = this.pos()[name];
    this.dragState = { name, startMx: e.clientX, startMy: e.clientY, startCx: p.x, startCy: p.y };
    this.selComp.set(name);
  }

  protected onSvgMouseDown(e: MouseEvent) {
    if ((e.target as Element).closest('[data-comp]')) return;
    this.panActive = true;
    this.panningState.set(true);
    this.panStart  = { x: e.clientX, y: e.clientY };
    this.panOrigin = { x: this.xfm().x, y: this.xfm().y };
  }

  protected onMouseMove(e: MouseEvent) {
    if (this.dragState) {
      const s  = this.xfm().s;
      const dx = (e.clientX - this.dragState.startMx) / s;
      const dy = (e.clientY - this.dragState.startMy) / s;
      this.pos.update(p => ({
        ...p,
        [this.dragState!.name]: {
          x: Math.round((this.dragState!.startCx + dx) / SNAP) * SNAP,
          y: Math.round((this.dragState!.startCy + dy) / SNAP) * SNAP,
        },
      }));
      return;
    }
    if (this.panActive) {
      this.xfm.update(t => ({
        ...t,
        x: this.panOrigin.x + (e.clientX - this.panStart.x),
        y: this.panOrigin.y + (e.clientY - this.panStart.y),
      }));
    }
  }

  protected onMouseUp() {
    this.dragState = null;
    this.panActive = false;
    this.panningState.set(false);
  }

  protected onWheel(e: WheelEvent) {
    e.preventDefault();
    const rect   = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const mx     = e.clientX - rect.left;
    const my     = e.clientY - rect.top;
    const factor = e.deltaY < 0 ? 1.12 : 0.89;
    this.xfm.update(t => {
      const ns = Math.max(0.12, Math.min(6, t.s * factor));
      return { x: mx - (mx - t.x) * (ns / t.s), y: my - (my - t.y) * (ns / t.s), s: ns };
    });
  }

  protected resetView() { this.xfm.set({ x: 0, y: 0, s: 1 }); }

  protected zoomIn() {
    this.zoomBy(1.15);
  }

  protected zoomOut() {
    this.zoomBy(0.87);
  }

  private zoomBy(factor: number) {
    const svg = this.svgElRef?.nativeElement;
    if (!svg) return;

    const cx = svg.clientWidth / 2;
    const cy = svg.clientHeight / 2;
    this.xfm.update(t => {
      const ns = Math.max(0.2, Math.min(4, t.s * factor));
      return {
        x: cx - (cx - t.x) * (ns / t.s),
        y: cy - (cy - t.y) * (ns / t.s),
        s: ns
      };
    });
  }

  protected fitAll(): boolean {
    const root = this.svgRootRef?.nativeElement;
    const svg  = this.svgElRef?.nativeElement;
    if (!root || !svg) return false;
    // Temporarily reset transform so getBBox measures the raw content
    root.setAttribute('transform', 'translate(0,0) scale(1)');
    try {
      const bb = root.getBBox();
      if (!bb.width || !bb.height) return false;
      const W   = svg.clientWidth;
      const H   = svg.clientHeight;
      if (!W || !H) return false;
      const pad = 40;
      const s   = Math.min((W - pad * 2) / bb.width, (H - pad * 2) / bb.height);
      this.xfm.set({
        x: (W - bb.width  * s) / 2 - bb.x * s,
        y: (H - bb.height * s) / 2 - bb.y * s,
        s,
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  protected deselectAll() { this.selComp.set(null); }
}
